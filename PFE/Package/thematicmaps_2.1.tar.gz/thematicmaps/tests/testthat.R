
library(testthat)

test_check("thematicmaps")
