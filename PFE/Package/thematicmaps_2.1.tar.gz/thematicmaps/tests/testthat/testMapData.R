
library(data.table)
library(testthat)
library(rgeos)


# Generate test polygons
set.seed(101)
a <- data.frame(x=rnorm(50), y=rnorm(50))
a <- a[chull(a), ]
b <- data.frame(x=2+rnorm(50), y=rnorm(50))
b <- b[chull(b), ]
c <- data.frame(x=2+rnorm(50), y=rnorm(50))
c <- c[chull(c), ]

sampleA <- as(a, "gpc.poly")
# get.pts(sampleA)

# Two area's, of which one has two pieces
testMapA <- data.frame(Identify="area1", x=a$x, y=a$y, hole=FALSE, piece=1, group="area1.1")
testMapB <- data.frame(Identify="area1", x=b$x, y=b$y, hole=FALSE, piece=2, group="area1.2")
testMapC <- data.frame(Identify="area2", x=c$x, y=c$y, hole=FALSE, piece=1, group="area2.1")
testMap <- rbind(testMapA, testMapB, testMapC)
testMap$order <- 1:nrow(testMap)

testMap <- testMap[, c("Identify", "x", "y", "order", "hole", "piece", "group")]

test_that("Functions are symmetrical",
{
  gpcPolygon <- MapData.ToGPCPoly(testMap)
  map <- MapData.FromGPCPoly(gpcPolygon)

  expect_true(sum(map!=testMap)==0)
})

test_that("Lists can be used in gpc polygon calculations",
{
  gpcPolygonsA <- MapData.ToGPCPoly(testMapA)
  gpcPolygonsB <- MapData.ToGPCPoly(testMapB)

  polA <- new("gpc.poly", pts=gpcPolygonsA[1, gpc][[1]])
  polB <- new("gpc.poly", pts=gpcPolygonsB[1, gpc][[1]])

  bboxA <- get.bbox(polA)
  bboxB <- get.bbox(polB)

  polC <- union(polA, polB)
  bboxC <- get.bbox(polC)

  expect_equal(bboxC$x[1],min(bboxA$x[1], bboxB$x[1]))
  expect_equal(bboxC$x[2],max(bboxA$x[2], bboxB$x[2]))
  expect_equal(bboxC$y[1],min(bboxA$y[1], bboxB$y[1]))
  expect_equal(bboxC$y[2],max(bboxA$y[2], bboxB$y[2]))
})


