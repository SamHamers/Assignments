
# General packages
library(data.table)
library(testthat)
library(rgeos)

sampleData <- ObjectLibrary("../../inst/SampleData")

selection <- thematicmaps:::.ObjectLibrary.QueryFull(sampleData, Area = "Congo", Type = "Polygon map")


  # Get ObjectLibrary directory
  elements <- strsplit(sampleData, "/")[[1]]
  libDir <- paste(elements[-length(elements)], collapse="/")

  readRDS(paste(libDir, selection$Path, sep="/"))


congoMap <- ObjectLibrary.Get(sampleData, Area = "Congo", Type = "Polygon map")
congoProvs <- ObjectLibrary.Get(sampleData, Area="Congo", Type="Regional data")[, c("ADM2", "ADM1")]

test_that("MapData.Aggregate needs unique groupingData",
{
  # Add duplicat key
  adm2Areas <- rbind(congoProvs, data.frame(ADM2=congoProvs[1, "ADM2"], ADM1="bla"))

  expect_error(MapData.Aggregate(congoMap, adm2Areas))
})


test_that("MapData.Aggregate throws error on missing id's",
{
  # remove ID
  adm2Areas <- congoProvs[-10,]

  expect_error(MapData.Aggregate(congoMap, adm2Areas), "Missing identifiers found.")
})


test_that("MapData.Aggregate throws message on unknown id's and groups correctly",
{
  # Add unknown ID
  adm2Areas <- rbind(congoProvs, data.frame(ADM2="UnknownID", ADM1="bla"))

  expect_message(MapData.Aggregate(congoMap, adm2Areas))

  provMap <- MapData.Aggregate(congoMap, adm2Areas)

  expect_equal(colnames(provMap)[1], "ADM1")
  expect_equal(length(unique(provMap[,1])), length(unique(congoProvs$ADM1)))
  expect_true(!(sum(unique(provMap[,1]) %in% unique(congoProvs$ADM1)))==0)
})

