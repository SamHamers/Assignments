
# Required packages
library(testthat)


################################################################################################
# Create MapDataLibrary                                                                        #
################################################################################################

test_that("MapDataLibrary creates an ObjectLibrary with specific fields",
{
  suppressWarnings(dir.create("Temp/mapLib"))
  file.remove(list.files("Temp/mapLib", full.names=TRUE))

  mapLib <- MapDataLibrary("Temp/mapLib")

  expect_equal(colnames(ObjectLibrary.Query(mapLib)), c("Year", "Area", "Level", "Type", "Source"))
})


test_that("MapDataLibrary tests existing ObjectLibrary on specific fields",
{
  oldIndex <- read.csv2(file="Temp/mapLib/ObjectLibrary")
  newIndex <- oldIndex[, -6]
  write.csv2(newIndex, file="Temp/mapLib/ObjectLibrary", row.names=FALSE)

  expect_error(MapDataLibrary("Temp/mapLib"))
})


test_that("Additional fields can be specified with MapDataLibrary",
{
  # One column
  file.remove(list.files("Temp/mapLib", full.names=TRUE))
  mapLib <- MapDataLibrary("Temp/mapLib", c("Additional"))
  expect_equal(colnames(ObjectLibrary.Query(mapLib)), c("Year", "Area", "Level", "Type", "Source", "Additional"))

  # Two columns
  file.remove(list.files("Temp/mapLib", full.names=TRUE))
  mapLib <- MapDataLibrary("Temp/mapLib", c("Additional", "Another"))
  expect_equal(colnames(ObjectLibrary.Query(mapLib)), c("Year", "Area", "Level", "Type", "Source", "Additional", "Another"))
})


test_that("SampleMapLibrary contains 7 objects with data or maps",
{
  sampleData <- MapDataLibrary("../../inst/SampleData")

  lib <- ObjectLibrary.Query(sampleData)

  expect_true(nrow(lib)==7)
  expect_equal(sum(c("Congo", "World", "Madagascar") %in% lib$Area), 3)
})

