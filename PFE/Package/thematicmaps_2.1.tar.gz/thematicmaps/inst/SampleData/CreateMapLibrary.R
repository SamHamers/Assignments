
library(maptools)
library(ggplot2)
library(digest)
library(data.table)

source("../../R/MapDataLibrary.R")
source("../../R/ObjectLibrary.R")
source("../../R/MapData.R")

mapLib <- MapDataLibrary(".")


# Congo
mapData <- MapData.FromShapefile("Congo.shp", "ADM2")
data <- mapData$Data
data <- aggregate(data, by=list(data$ADM2), FUN=function(x){x[1]})[, c("ADM2", "ADM1", "ADM0")]
ObjectLibrary.Add(mapLib, data, Area="Congo", Year=2012, Level="ADM2", Type="Regional data", Source="www.maplibrary.org")
ObjectLibrary.Add(mapLib, mapData$Geometry, Area="Congo", Year=2012, Level="ADM2", Type="Polygon map", Source="www.maplibrary.org")


# Countries
# MapData.ShapeInfo("Countries.shp")
mapData <- MapData.FromShapefile("Countries.shp", "name")
setnames(mapData$Geometry, "name", "Country")
data <- mapData$Data
setnames(data, "name", "Country")
data <- aggregate(data, by=list(data$Country), FUN=function(x){x[1]})[, c("Country", "sovereignt",
  "sov_a3", "type", "abbrev", "pop_est", "gdp_md_est", "economy", "income_grp", "continent",
  "region_un", "subregion", "region_wb")]
ObjectLibrary.Add(mapLib, data, Area="World", Year=2012, Level="Country", Type="Regional data", Source="www.maplibrary.org")
ObjectLibrary.Add(mapLib, mapData$Geometry, Area="World", Year=2012, Level="Country", Type="Polygon map", Source="www.maplibrary.org")


# Madagascar
# MapData.ShapeInfo("Madagascar.shp")
mapData <- MapData.FromShapefile("Madagascar.shp", "ADM2")
data <- mapData$Data
data <- aggregate(data, by=list(data$ADM2), FUN=function(x){x[1]})[, c("ADM2", "ADM1", "ADM0")]
print(mapData$Type)
ObjectLibrary.Add(mapLib, data, Area="Madagascar", Year=2012, Level="ADM2", Type="Regional data", Source="www.maplibrary.org")
ObjectLibrary.Add(mapLib, mapData$Geometry, Area="Madagascar", Year=2012, Level="ADM2", Type="Polygon map", Source="www.maplibrary.org")


# TownPoints
# MapData.ShapeInfo("TownPoints.shp")
mapData <- MapData.FromShapefile("TownPoints.shp", "nameascii")
data <- mapData$Data
setnames(data, "nameascii", "City")
data <- data[, c("City", "scalerank", "natscale", "sov_a3", "adm0name", "adm1name", "iso_a2",
                 "longitude", "latitude")]
ObjectLibrary.Add(mapLib, data, Area="World", Year=2012, Level="City", Type="Point map", Source="www.maplibrary.org")

