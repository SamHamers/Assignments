
# Contents

[TOC]

# Introduction

An MapDataLibrary offers a simple and convenient way of accessing your maps. By specifying the characteristics of the map, maps or map
data can be found and loaded. A well documented MapDataLibrary can help you create maps efficiently.

# Querying a MapDataLibrary

A sample MapData library is included in the SampleData directory of the ThematicMaps package.


```r
library(ThematicMaps)
mapLib <- SampleMapLibrary()
```

A MapDataLibrary can be accessed through the ObjectLibrary commands. This means that it can be queried
with the ObjectLibrary.Query method:


```r
ObjectLibrary.Query(mapLib) # Show content of the MapLibrary
```

```
##   Year       Area   Level          Type             Source
## 1 2012      Congo    ADM2 Regional data www.maplibrary.org
## 2 2012      Congo    ADM2   Polygon map www.maplibrary.org
## 3 2012      World Country Regional data www.maplibrary.org
## 4 2012      World Country   Polygon map www.maplibrary.org
## 5 2012 Madagascar    ADM2 Regional data www.maplibrary.org
## 6 2012 Madagascar    ADM2   Polygon map www.maplibrary.org
## 7 2012      World    City     Point map www.maplibrary.org
```

The query can be narrowed down by specifying additional search parameters:


```r
ObjectLibrary.Query(mapLib, Level="ADM2") # Narrow down the search
```

```
##   Year       Area Level          Type             Source
## 1 2012      Congo  ADM2 Regional data www.maplibrary.org
## 2 2012      Congo  ADM2   Polygon map www.maplibrary.org
## 5 2012 Madagascar  ADM2 Regional data www.maplibrary.org
## 6 2012 Madagascar  ADM2   Polygon map www.maplibrary.org
```

More than one parameter be be used in the query, the result shows map data that fullfills all criteria (e.g. && operator):


```r
ObjectLibrary.Query(mapLib, Area="Madagascar", Level="ADM2") # Multiple parameters can be specified
```

```
##   Year       Area Level          Type             Source
## 5 2012 Madagascar  ADM2 Regional data www.maplibrary.org
## 6 2012 Madagascar  ADM2   Polygon map www.maplibrary.org
```

For each parameter, a vector can be specified. The search then includes a range of values for that parameter:


```r
ObjectLibrary.Query(mapLib, Area=c("Congo", "Madagascar"), Level="ADM2") # A range of parameter values
```

```
##   Year       Area Level          Type             Source
## 1 2012      Congo  ADM2 Regional data www.maplibrary.org
## 2 2012      Congo  ADM2   Polygon map www.maplibrary.org
## 5 2012 Madagascar  ADM2 Regional data www.maplibrary.org
## 6 2012 Madagascar  ADM2   Polygon map www.maplibrary.org
```

# Loading maps from a MapData library

Once you have a query that resolves into a single map, you can use these parameters to retrieve the map.


```r
madagascarMap <- ObjectLibrary.Get(mapLib, Area="Madagascar", Type="Polygon map") # Load data
```

Plotting this map is simple with the ThematicMaps package.


```r
AddMapLayer(MapPlot(), madagascarMap) # Plot default map
```

![plot of chunk MadagascarDefault](figure/MadagascarDefault-1.png) 

A MapData library usualy contains maps and the associated data. For example, alongside the Madagascar map, you will also find a data file that can be found with the same parameters but it's Type set to "Regional data".


```r
madagascarData <- ObjectLibrary.Get(mapLib, Area="Madagascar", Type="Regional data") # Madagascar map data
head(madagascarData[, c("ADM2", "ADM0", "ADM1")]) # Show some fileds
```

```
##                 ADM2       ADM0         ADM1
## 1          Ambalavao Madagascar Fianarantsoa
## 2            Ambanja Madagascar  Antsiranana
## 3       Ambato-Boina Madagascar    Mahajanga
## 4 Ambatofinandrahana Madagascar Fianarantsoa
## 5        Ambatolampy Madagascar Antananarivo
## 6       Ambatomainty Madagascar    Mahajanga
```

# Create your own MapData library

You can also create a new MapData library with the MapDataLibrary method. Just use an empty (existing) directory as the target for the library.


```r
# Create a new directory
if (file.exists("MapDataLibTemp")) unlink("MapDataLibTemp", force=TRUE, recursive=TRUE)
dir.create("MapDataLibTemp")

# Create a new MapData library
mapLibrary <- MapDataLibrary("MapDataLibTemp")
```

```
## New ObjectLibrary created.
```

Make sure the directory exists before creating a new library (directory 'MapDataLibTemp' in the example code)!
A query to the newly created library will show an empty list:


```r
ObjectLibrary.Query(mapLibrary)
```

```
## [1] Year   Area   Level  Type   Source
## <0 rows> (or 0-length row.names)
```

Note that you can specify addional metadata fields with the additionalMetaFields parameter. These fields will show up as additional
columns in the query.


# Add shapefiles to the library

The ThematicMaps package contains a SampleData directory with shapefiles of Congo, Madagascar and a worldmap (from www.maplibrary.org). The paths to these shapefiles can be found with:


```r
congoShp <- paste(path.package("ThematicMaps"), "SampleData", "Congo.shp", sep="/")
```

By using MapData methods, you can get info on a shapefile:



```r
mapData <- MapData.ShapeInfo(congoShp)
```

```
## Field name: 'STL-0' changed to: 'STL.0'
## Field name: 'STL-1' changed to: 'STL.1'
## Field name: 'STL-2' changed to: 'STL.2'
## Field name: 'STL-3' changed to: 'STL.3'
## Field name: 'STL-4' changed to: 'STL.4'
## Field name: 'STL-5' changed to: 'STL.5'
```

```
## [1] "Shapefile is of class SpatialPolygonsDataFrame"
## [1] "data"        "polygons"    "plotOrder"   "bbox"        "proj4string"
## [1] "The following columns are available in the shapefile dataset:"
##  [1] "ID"         "LBL"        "FIP"        "MMT_ID"     "SHORT__FRM"
##  [6] "LONG_FRM"   "ADM0"       "ADM1"       "ADM2"       "ADM3"      
## [11] "ADM4"       "ADM5"       "STL.0"      "STL.1"      "STL.2"     
## [16] "STL.3"      "STL.4"      "STL.5"     
## [1] ""
## [1] "Data header"
##   ID   LBL FIP MMT_ID SHORT__FRM                         LONG_FRM  ADM0
## 0  1 ZAI-1  CG    ZAI      Congo Democratic Republic of the Congo Congo
## 1  2 ZAI-2  CG    ZAI      Congo Democratic Republic of the Congo Congo
## 2  3 ZAI-3  CG    ZAI      Congo Democratic Republic of the Congo Congo
## 3  4 ZAI-4  CG    ZAI      Congo Democratic Republic of the Congo Congo
## 4  5 ZAI-5  CG    ZAI      Congo Democratic Republic of the Congo Congo
## 5  6 ZAI-6  CG    ZAI      Congo Democratic Republic of the Congo Congo
##       ADM1    ADM2 ADM3 ADM4 ADM5 STL.0 STL.1 STL.2 STL.3 STL.4 STL.5
## 0 Bas-Uele    Polo    -    -    -    55     1     1     -     -     -
## 1 Bas-Uele    Buta    -    -    -    55     1     2     -     -     -
## 2 Bas-Uele   Bondo    -    -    -    55     1     3     -     -     -
## 3 Bas-Uele Bambesa    -    -    -    55     1     4     -     -     -
## 4 Bas-Uele    Ango    -    -    -    55     1     5     -     -     -
## 5 Bas-Uele   Aketi    -    -    -    55     1     6     -     -     -
```

You can use this info to check for a suitable level to use for converting the map. Look for a parameter that is different on every line:


```r
mapDataCollection <- MapData.FromShapefile(congoShp, "ADM2")
```

```
## Field name: 'STL-0' changed to: 'STL.0'
## Field name: 'STL-1' changed to: 'STL.1'
## Field name: 'STL-2' changed to: 'STL.2'
## Field name: 'STL-3' changed to: 'STL.3'
## Field name: 'STL-4' changed to: 'STL.4'
## Field name: 'STL-5' changed to: 'STL.5'
```

The result is a list with three parts: geometry data, regional data and a type:


```r
names(mapDataCollection)
```

```
## [1] "Data"     "Geometry" "Type"
```

When adding a shapefile to the MapData library, you have to specify the metadata of the map:


```r
ObjectLibrary.Add(mapLibrary, mapDataCollection$Geometry, Year=2012, Area="Congo", Level="ADM2", Type="Polygon map", Source="www.maplibrary.org")
ObjectLibrary.Add(mapLibrary, mapDataCollection$Data, Year=2012, Area="Congo", Level="ADM2", Type="Regional data", Source="www.maplibrary.org")
```

The maps are now available from the library and can be accessed as described above:


```r
ObjectLibrary.Query(mapLibrary)
```

```
##   Year  Area Level          Type             Source
## 1 2012 Congo  ADM2   Polygon map www.maplibrary.org
## 2 2012 Congo  ADM2 Regional data www.maplibrary.org
```

Now you are set to create thematic maps from the availbale data and polygons!


```r
map <- ObjectLibrary.Get(mapLibrary, Type="Polygon map")
provs <- ObjectLibrary.Get(mapLibrary, Type="Regional data")[, c("ADM2", "ADM1")]
AddMapLayer(MapPlot(), map, provs)
```

![plot of chunk unnamed-chunk-16](figure/unnamed-chunk-16-1.png) 

