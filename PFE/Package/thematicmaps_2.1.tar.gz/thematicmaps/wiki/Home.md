
# ThematicMaps

Below you can find links to documentation on the various aspects of the ThematicMaps R-package.

* [Using and creating a MapDataLibrary](MapData/MapData.md)
* [Building thematic maps](Maps/Maps.md)

This wiki was automatically generated using ThematicMaps version 1.8.3. You can find the package release notes [here](ReleaseNotes.md)
