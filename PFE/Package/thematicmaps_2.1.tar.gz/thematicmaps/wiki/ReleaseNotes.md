# Release notes for R-package ThematicMaps 

> Check out new features and fixed bugs below. You are encouraged to report bugs or submit feature requests at the package
[issue tracker](https://bitbucket.org/NZaAnalysis/thematicmaps/issues "https://bitbucket.org/NZaAnalysis/thematicmaps/issues"). More detailed information on the package functionality can be found on the [wiki](https://bitbucket.org/NZaAnalysis/thematicmaps/wiki "https://bitbucket.org/NZaAnalysis/thematicmaps/wiki").

## *This release (version v1.8.3)*

###### *Mon May 11 13:12:04 2015 +0200*
[![image not found](ReleaseNotesImages/task.png "BitBucket issue 41")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/41) **Package** Update package to R version 3.2.0 (*MarkKlik*)



## *Version v1.8.2*

###### *Mon Dec 09 11:16:21 2013 +0100*
[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 26")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/26) **Mapping algorithm** Error using method unit (*MarkKlik*)

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 33")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/33) **Mapping algorithm** AggregateMapData crashes on missing hole (*MarkKlik*)

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 35")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/35) **Mapping algorithm** MapData.FromShapeFile throws error on wrong level for line data (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 21")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/21) **Object library** Add any object to a MapDataLibrary (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 30")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/30) **Object library** Mapinfo and Shapefile conversion funcionality is separated from object library (*MarkKlik*)

[![image not found](ReleaseNotesImages/task.png "BitBucket issue 24")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/24) **Documentation** Do not use NZaMapLibrary on the wiki (*MarkKlik*)

[![image not found](ReleaseNotesImages/task.png "BitBucket issue 34")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/34) **Object library** Move ObjectLibrary functionality to package DataTools (*MarkKlik*)

[![image not found](ReleaseNotesImages/task.png "BitBucket issue 31")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/31) **Package** Package builds with PackageManager tools (*MarkKlik*)



## *Version v1.8.1*

###### *Mon Jul 15 14:48:57 2013 +0200*
[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 25")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/25) **Mapping algorithm** Problems with the rescaler in color-range maps (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 9")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/9) **Data** Allow data description with MapData.Add (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 12")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/12) **Data** Methods for converting MapInfo files to the Shapefile format (*MarkKlik*)

[![image not found](ReleaseNotesImages/task.png "BitBucket issue 5")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/5) **Documentation** Convert documentation to roxygen2 (*MarkKlik*)



## *Version v1.8.0*

###### *Mon May 27 12:49:24 2013 +0200*
[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 23")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/23) **Mapping algorithm** Add functionality to create unions of map polygons (*MarkKlik*)



## *Version v1.7.0*

###### *Thu May 16 13:55:47 2013 +0200*
[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 22")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/22) **General** Use subset to subset index file (*MarkKlik*)



## *Version v1.6.0*

###### *Mon May 13 10:14:06 2013 +0200*
[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 6")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/6) **Documentation** Add documentation with example code (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 11")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/11) **Data** Add small MapData library to the package (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 13")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/13) **Data** Add fields Area, Source and Description to the MapData library (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 17")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/17) **Data** Remove Italy datasets (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 18")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/18) **Data** Add function for access to sample MapDataLibrary (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 15")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/15) **General** Get common build script from BitBucket (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 10")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/10) **Mapping algorithm** Allow multiple levels in queries (*MarkKlik*)

[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 16")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/16) **Mapping algorithm** A MapData library should have a dedicated class to hide implementation details (*MarkKlik*)



## *Version v1.5.0*

###### *Fri Apr 19 13:25:21 2013 +0200*
[![image not found](ReleaseNotesImages/feature.png "BitBucket issue 7")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/7) **Data** Create MapLibrary function for easy access to available maps (*MarkKlik*)



## *Version v1.4.1*

###### *Fri Apr 05 14:03:54 2013 +0200*
[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 2")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/2) **General** The package gets errors due to the ggplot2 package update (*MarkKlik*)



## *Working on*

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 40")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/40) **Mapping algorithm** Error 'Location identifier '1' is unknown, dropping line' when using data.table (*MarkKlik*)

----------

## Known issues

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 38")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/38) **General** Aggregate function for polygons

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 39")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/39) **General** Create a simpler map from a complex map

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 19")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/19) **Mapping algorithm** Error with zooming function

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 20")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/20) **Mapping algorithm** Warning with option legendPosition="none"

[![image not found](ReleaseNotesImages/bug.png "BitBucket issue 29")](https://bitbucket.org/NZaAnalysis/thematicmaps/issue/29) **Mapping algorithm** R crashes when drawing continuous scale with only one value

