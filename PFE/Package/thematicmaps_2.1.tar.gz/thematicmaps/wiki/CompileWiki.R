
library(knitr)

BuildWiki <- function()
{
  KnitAndPurl <- function()
  {
    docs <- list.files(".", ".Rmd$", recursive=TRUE, full.names=TRUE)
    baseDir <- getwd()
    
    for (doc in docs)
    {
      dir <- strsplit(doc, "/", fixed=TRUE)[[1]]
      dir <- paste(dir[-length(dir)], collapse="/", sep="")
      
      docFile <- strsplit(doc, paste(dir, "/", sep=""), fixed=TRUE)[[1]][2]
      docFile <- strsplit(docFile, ".", fixed=TRUE)[[1]]
      docFile <- paste(docFile[1:(length(docFile)-1)], collapse="", sep="")
      
      setwd(dir)
      knit(paste(docFile, ".Rmd", sep=""), paste(docFile, ".md", sep=""))
      purl(paste(docFile, ".Rmd", sep=""), paste(docFile, ".R", sep=""), documentation=2)
      setwd(baseDir)
    }
  }
  
  CheckAllCode <- function()
  {
    docs <- list.files(".", ".R$", recursive=TRUE, full.names=TRUE)
    docs <- docs[docs!="./CompileWiki.R"]
    
    for (doc in docs)
    {
      print(doc)
      source(doc, echo=TRUE)
    }
  }
  
  # Generate document and code:
  if (class(try(KnitAndPurl()))=="try-error") return(FALSE)

  # Check extracted code for errors:
  if (class(try(CheckAllCode()))=="try-error") return(FALSE)
  
  # Everything oke
  return(TRUE)
}



