
# Contents

[TOC]

# Creating thematic maps

The following documentation is a step-by-step guide to thematic map building.

## Using a MapDataLibrary to plot a default map

To plot a map, we need map data. A convenient way to store and retrieve maps and map data is a MapDataLibrary. For detailed information on building and accessing your own MapDataLibrary, see the dedicated [Wiki page](https://bitbucket.org/NZaAnalysis/thematicmaps/wiki/MapData/MapData.md). In the following guide, we will use the sample MapDataLibrary from the ThematicMaps package.


```r
library(ThematicMaps)
mapLib <- SampleMapLibrary()
```

You can load and plot a map from the library with


```r
congoMap <- ObjectLibrary.Get(mapLib, Area="Congo", Type="Polygon map") # Retrieve map from library
AddMapLayer(MapPlot(), congoMap) # Plot Congo at admin level 2
```

![plot of chunk unnamed-chunk-2](figure/unnamed-chunk-2-1.png) 

## Changing default map settings

A background area is an area on the map that is not connected to data in the provided data file. In a default map, there is no data file specified, so all plotted areas are background areas. You can change the color of background areas:


```r
AddMapLayer(MapPlot(), congoMap, backgroundAreasColor = "blue") # Plot Congo in blue
```

![plot of chunk unnamed-chunk-3](figure/unnamed-chunk-3-1.png) 

or the color of the lines araound the areas:


```r
AddMapLayer(MapPlot(), congoMap, backgroundAreasColor = "transparent", lineColor = "green") # Plot Congo in black lines
```

![plot of chunk unnamed-chunk-4](figure/unnamed-chunk-4-1.png) 

If you need only a part of the total map, you can make a selection. In this example we use the datafile on Congo that is also present in the MapDataLibrary. Note that in any MapDataLibrary, the polygon files usualy have a counterpart file containing additional data.
To plot a default map of the Lualaba province with its ADM2 areas, we can use:


```r
congoData <- ObjectLibrary.Get(mapLib, Area="Congo", Type="Regional data")
LualabaProvince <- congoData[congoData$ADM1 == "Lualaba", c("ADM2", "ADM1")]
smallCongoMap <- congoMap[congoMap$ADM2 %in% LualabaProvince$ADM2,]

AddMapLayer(MapPlot(), smallCongoMap) # Plot Congo in black lines
```

![plot of chunk unnamed-chunk-5](figure/unnamed-chunk-5-1.png) 

We can also use the zoom option of the AddMapLayer method:


```r
# Currently not working (see issues)
# AddMapLayer(MapPlot(), congoMap, zoomBoundary=c(0.1, 0.1, 0.5, 0.5)) # Plot Congo at admin level 2
```

## Plotting data

### Factor vs. non-factor data

There are two categories of data that can be plotted: factors and non-factors. A factor is an enumerated type:


```r
factor(c(1, 5, 9, 5, 1))
```

```
## [1] 1 5 9 5 1
## Levels: 1 5 9
```

In R, working with factors is tricky, for example:


```r
as.numeric(factor(c(1, 5, 9, 5, 1)))
```

```
## [1] 1 2 3 2 1
```

The underlying type-numbers are used in the function as.numeric, and not the actual data (very error-prone)!
Plotting factor data on a map will result in the plotting of all available categories in its own color. Numerical data (non-factor) on the other hand, will result in plotting in a continuous color scale. To see the difference, here are the ADM2 levels in the Lualaba province (make sure you run the code above first):


```r
LualabaRegions <- data.frame(ADM2=LualabaProvince$ADM2, Region=LualabaProvince$ADM2)
AddMapLayer(MapPlot(), congoMap, LualabaRegions) # Plot Lualaba provine in Congo
```

![plot of chunk unnamed-chunk-9](figure/unnamed-chunk-9-1.png) 

And here is a plot with non-factor data for the same regions:


```r
LualabaData <- data.frame(ADM2=LualabaProvince$ADM2, Data=sample(1:10, 5))
AddMapLayer(MapPlot(), congoMap, LualabaData) # Plot Lualaba provine in Congo
```

![plot of chunk unnamed-chunk-10](figure/unnamed-chunk-10-1.png) 

In the first case, the legend shows all available categories and in the second map a continuous scale is drawn. Always make sure your data is of the correct type before plotting.
When your are plotting data, you can set the backgroundAreasColor to NULL to draw only areas with data. That way, no pre-selection in the map data in neccesary:


```r
AddMapLayer(MapPlot(), congoMap, LualabaData, backgroundAreasColor=NULL) # Plot Lualaba province zoom
```

![plot of chunk unnamed-chunk-11](figure/unnamed-chunk-11-1.png) 

### The map legend

You can tune the legend and its colors to your specific needs. The AddMapLayer function uses the ggplot method 'scale_fill_manual' to set the legend for factor data and the ggplot method 'scale_fill_gradientn' for continuous data. You can set parameters for these methods by setting the categoryColors argument to a list of named parameters:


```r
library(RColorBrewer)

categoryColors = list(colours=brewer.pal(5, "Oranges"))
AddMapLayer(MapPlot(), congoMap, LualabaData, categoryColors=categoryColors, backgroundAreasColor=NULL) # Plot Lualaba province in custom colors
```

![plot of chunk unnamed-chunk-12](figure/unnamed-chunk-12-1.png) 

Use the documentation on the two ggplot methods to finetune your legend. This documentation can be found online, for example: https://www.google.nl/search?q=ggplot2+scale_fill_gradientn

If you don't want a legend, simply turn it off with:


```r
AddMapLayer(MapPlot(), congoMap, LualabaData) + theme(legend.position="none")  # Plot Lualaba province without legend
```

![plot of chunk unnamed-chunk-13](figure/unnamed-chunk-13-1.png) 

Or place it at a different location in the map:


```r
AddMapLayer(MapPlot(), congoMap, LualabaData) + theme(legend.position="top")  # Plot Lualaba province with a legend at the top
```

![plot of chunk unnamed-chunk-14](figure/unnamed-chunk-14-1.png) 

### Add point data to the map

The sample MapData library also contains a Points_Data file. This file contains the location of 243 'world cities' (downloaded from http://www.naturalearthdata.com). To plot the contents, first plot a default world map:


```r
worldMap <- ObjectLibrary.Get(mapLib, Area="World", Type="Polygon map")
map <- AddMapLayer(MapPlot(), worldMap)
print(map)
```

![plot of chunk unnamed-chunk-15](figure/unnamed-chunk-15-1.png) 

Then overlay the point with AddPointsLayer.


```r
townData <- ObjectLibrary.Get(mapLib, Area="World", Type="Point map") # Load town data
towns <- townData[, c("City", "longitude", "latitude")] # Subset data
colnames(towns) <- c("Town", "X", "Y") # Column 2 and 3 have to be named 'X' and 'Y'

AddPointsLayer(map, towns) # Overlay points on the map
```

![plot of chunk unnamed-chunk-16](figure/unnamed-chunk-16-1.png) 

## Aggregating polygons in the map (currently not working)

With the method AggregateMapData, we can calculate the union of polygons according to a specified grouping rule:


```r
ObjectLibrary.Query(mapLib)
```

```
##   Year       Area   Level          Type             Source
## 1 2012      Congo    ADM2 Regional data www.maplibrary.org
## 2 2012      Congo    ADM2   Polygon map www.maplibrary.org
## 3 2012      World Country Regional data www.maplibrary.org
## 4 2012      World Country   Polygon map www.maplibrary.org
## 5 2012 Madagascar    ADM2 Regional data www.maplibrary.org
## 6 2012 Madagascar    ADM2   Polygon map www.maplibrary.org
## 7 2012      World    City     Point map www.maplibrary.org
```

```r
map <- ObjectLibrary.Get(mapLib, Area="Madagascar", Type="Polygon map")
groupingList <- ObjectLibrary.Get(mapLib, Area="Madagascar", Type="Regional data")

# aggrMap <- AggregateMapData(map, groupingList[,1:2])
```

Now you can plot the original map with boundaries around the grouped areas:



```r
plot <- AddMapLayer(MapPlot(), map)
# AddMapLayer(plot, aggrMap, lineColor="dark grey", backgroundAreasColor="transparent", size=1)
```

In this map, the underlying polygons are merged into larger regions which can then be used to draw additional features on the map.
