
.CreateGPCPolyGroup <- function(group, gpcPoly)
{
  result <- list()

  result[[1]] <- gpcPoly
  names(result[[1]]) <- group

  result
}

.CreateGPCPoly <- function(ID, x, y, hole)
{
  result <- list()

  result[[1]] <- list()
  result[[1]]$x <- x
  result[[1]]$y <- y
  result[[1]]$hole <- hole[1]

  result
}

.ExpandGpcPolyGroup <- function(gpcPoly)
{
  data.table(group=names(gpcPoly[[1]]), gpcGroup=gpcPoly[[1]], piece=1:length(gpcPoly[[1]]))
}

.ExpandGpcPoly <- function(gpcPoly)
{
  data.table(x=gpcPoly[[1]]$x, y=gpcPoly[[1]]$y, hole=gpcPoly[[1]]$hole)
}


#'MapToGPCPoly
#'
#'Convert map data to a list of GPC polygons (for use with the rgeos package).
#'
#'
#'@param mapData Map polygon data.
#'@export
#'@author Mark Klik <mklik@@nza.nl>
MapToGPCPoly <- function(mapData)
{
  map <- data.table(mapData)

  setnames(map, colnames(mapData)[1], "ID")
  x <- map[, list(ID=ID[1], gpc= .CreateGPCPoly(ID, x, y, hole)), by=group]

  y <- x[, list(gpc=.CreateGPCPolyGroup(group, gpc)), by=ID]

  setnames(y, "ID", colnames(mapData)[1])

  setkeyv(y, colnames(mapData)[1])

  y
}


#'GPCPolyToMap
#'
#'Convert a data.table of GPC polygons (rgeos package) to map data.
#'
#'
#'@param gpcPolygons A named list of GPC polygons as defined in the rgeos package.
#'@export
#'@author Mark Klik <mklik@@nza.nl>
GPCPolyToMap <- function(gpcPolygons)
{
  colName <- colnames(gpcPolygons)[1]

  setnames(gpcPolygons, colName, "ID")

  groupTable <- gpcPolygons[, .ExpandGpcPolyGroup(gpc), by=ID]

  table <- groupTable[, .ExpandGpcPoly(gpcGroup), by="ID,group,piece"]

  table$order <- 1:nrow(table)

  setnames(table, "ID", colName)
  
  as.data.frame(table)[,c(colName, "x", "y", "order", "hole", "piece", "group")]
}
