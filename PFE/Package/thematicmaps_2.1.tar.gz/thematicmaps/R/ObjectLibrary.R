
.RequiredFields <- function()
{
  c("Path")
}

#' ObjectLibrary
#'
#' Create a new object library
#'
#'
#' @param objectLibraryDirectory Path to the directory where the library exists or a new library
#' should be created.
#' @param metaDataFields The metadata fields that have to be added to the library. If NULL, only
#' default fields will be added. This parameter is only used when a new library is created.
#' @export
#' @return A reference to a newly created or existing object library.
#' @author Mark Klik <mklik@@nza.nl>
ObjectLibrary <- function(objectLibraryDirectory, metaDataFields=NULL)
{
  if (!file.exists(objectLibraryDirectory))
  {
    dir.create(objectLibraryDirectory, recursive=TRUE)
  }
  
  lib <- paste(objectLibraryDirectory, "ObjectLibrary", sep="/")
  
  if (!file.exists(lib))
  {
    # Default fields required for all libraries
    columnNames <- unique(c(.RequiredFields(), metaDataFields))

    if (length(columnNames)<2)
    {
      stop("An object library needs at least one metaDataField to correctly distinquish data.")
    }
    
    index <- matrix(character(), 0, length(columnNames))
    colnames(index) <- columnNames
    
    # Create empty index file
    emptyIndex <- data.frame(index)
    
    write.csv2(emptyIndex, lib, row.names=FALSE)
    message("New ObjectLibrary created.")
  } else
  {
    message("ObjectLibrary initialized.")
  }
  
  class(lib) <- "ObjectLibrary"
  lib
}


.ObjectLibrary.GetIndex <- function(objectLibrary)
{
  if (class(objectLibrary) != "ObjectLibrary")
  {
    message("Please create a valid ObjectLibrary with method ObjectLibrary.")
    return(NULL)
  }

  # Get index
  index <- read.csv2(objectLibrary, stringsAsFactors=FALSE, colClasses="character")
  
  # Verify index
  if (sum(.RequiredFields() %in% colnames(index))!=1)
  {
    stop("Error, corrupt object library. Please use method ObjectLibrary to create a valid library.")
  }
  
  index
}


.ObjectLibrary.QueryFull <- function(objectLibrary, ...)
{
  index <- .ObjectLibrary.GetIndex(objectLibrary)
  if (is.null(index)) return(invisible(NULL))
  
  args <- as.list(match.call())
  parameters <- args[!(names(args) %in% c("", "objectLibrary"))]
  
  for (parameterName in names(parameters))
  {
    if (!(parameterName %in% colnames(index)))
    {
      message("Warning, parameter ", parameterName, " can not be used to subset the object library.")
      next
    }
    
    value <- parameters[parameterName][[1]]
    value <- eval(value, envir = parent.frame(n=1))
    
    index <- index[index[, parameterName] %in% value, ]
  }
  
  index
}


#' print.ObjectLibrary
#'
#' Default printing of object library
#'
#'
#' @param objectLibrary A valid object library created with method 'ObjectLibrary'.
#' @export
#' @author Mark Klik <mklik@@nza.nl>
print.ObjectLibrary <- function(objectLibrary) {print(ObjectLibrary.Query(objectLibrary), row.names=FALSE)}


#' ObjectLibrary.Query
#'
#' Query an object library
#'
#'
#' @param objectLibrary A valid object library created with method 'ObjectLibrary'.
#' @param ... Query parameters to subset the available objects
#' @export
#' @return A list of objects in the library that are valid results from the query
#' @author Mark Klik <mklik@@nza.nl>
ObjectLibrary.Query <- function(objectLibrary, ...)
{
  index <- .ObjectLibrary.QueryFull(objectLibrary, ...)

  index[, setdiff(colnames(index), "Path"), drop=FALSE]
}


#' ObjectLibrary.Add
#'
#' Add an object and its metadata to the library
#'
#'
#' @param objectLibrary A valid object library created with method ObjectLibrary
#' @param object Object to add to the library
#' @param overwrite If TRUE, allows data in the library to be overwritten
#' @param ... Parameters to identify the object in the library. All fields required for
#' the current object library must be specified.
#' @export
#' @author Mark Klik <mklik@@nza.nl>
ObjectLibrary.Add <- function(objectLibrary, object, overwrite=FALSE, ...)
{
  index <- .ObjectLibrary.GetIndex(objectLibrary)
  if (is.null(index)) return(invisible(NULL))

  # Verify supplied arguments
  args <- as.list(match.call())
  
  parameters <- args[!(names(args) %in% c("", "objectLibrary", "object", "overwrite", "Path"))]
  
  # Evaluate parameters (for indirect calls)
  for (parameterName in names(parameters))
  {
    value <- parameters[parameterName][[1]]
    value <- eval(value, envir = parent.frame(n=1))
    
    parameters[parameterName] <- value
  }

  missingParameters <- colnames(index)[!(colnames(index) %in% c("Path", names(parameters)))]
  if (length(missingParameters) > 0)
  {
    stop("Please set all required parameters. This object library requires the following additional parameters: \n",
      paste(missingParameters, collapse=", "))
  }
  
  parameters <- unlist(parameters)
  
  subs <- strsplit(objectLibrary, "/")[[1]]
  dirName <- paste(subs[-length(subs)], collapse="/")

  # Check if object already in index
  entry <- .ObjectLibrary.QueryFull(objectLibrary, ...)

  # Overwrite previously saved object
  if (nrow(entry) > 0)
  {
    if (!overwrite)
    {
      stop("An object with this metadata is already present in the library, please change parameters or set overwrite=TRUE")
    }
    
    message("An object with this metadata is already present in the library, overwriting...")
    
    if (nrow(entry) > 1)
    {
      stop("Error saving object, multiple entries found with identical metadata found. Library may be corrupt.")
    }

    # Remove old object from index
    index <- index[index$Path!=entry$Path, ]
    oldFile <- paste(dirName, entry$Path, sep="/")
    if (file.exists(oldFile)) file.remove(oldFile)
  }
  
  # Save geometry to .rds file
  metaHash <- digest(parameters[names(parameters) %in% colnames(index)])
  objectFileName <- paste(metaHash, ".rds", sep="")
  
  if (objectFileName %in% index$Path)
  {
    stop("Error, duplicate entry found in object library, it may be corrupt!")
  }
  
  saveRDS(object, file=paste(dirName, objectFileName, sep="/"))
  
  # Create index row
  row <- data.frame(matrix(0, 1, length(parameters)))
  colnames(row) <- names(parameters)
  row[1,] <- parameters
  
  # Create object entry
  row$Path <- objectFileName
  index <- rbind(index, row[, colnames(index)])
  
  write.csv2(index, file=objectLibrary, row.names=FALSE, na="")
}


#' ObjectLibrary.Get
#'
#' Get an object from the object library
#'
#'
#' @param objectLibrary A valid object library created with method 'ObjectLibrary'.
#' @param ... Descriptors of the metadata of the object that you want to retrieve.
#' @export
#' @return The object selected from the specified metadata.
#' @author Mark Klik <mklik@@nza.nl>
ObjectLibrary.Get <- function(objectLibrary, ...)
{
  if (class(objectLibrary) != "ObjectLibrary")
  {
    message("Please create a valid object library with method 'ObjectLibrary'.")
    return(invisible(NULL))
  }
  
  selection <- .ObjectLibrary.QueryFull(objectLibrary, ...)
  
  if (nrow(selection)>1)
  {
    message("Multiple objects are present in the library for the current selection of parameters, please specify:")
    print(selection[, colnames(selection)[!(colnames(selection) %in% "Path")]])
    return(invisible(NULL))
  }
  
  if (nrow(selection)==0)
  {
    message("No object present in the library for the current selection of parameters.")
    return(invisible(NULL))
  }
  
  # Get ObjectLibrary directory
  elements <- strsplit(objectLibrary, "/")[[1]]
  libDir <- paste(elements[-length(elements)], collapse="/")
  
  readRDS(paste(libDir, selection$Path, sep="/"))
}


#' ObjectLibrary.Remove
#'
#' Remove an object from the object library
#'
#'
#' @param objectLibrary A valid object library created with method 'ObjectLibrary'.
#' @param ... Descriptors of the metadata of the object that you want to remove from the library.
#' @export
#' @return TRUE if removal was succesful, otherwise FALSE.
#' @author Mark Klik <mklik@@nza.nl>
ObjectLibrary.Remove <- function(objectLibrary, ...)
{
  if (class(objectLibrary) != "ObjectLibrary")
  {
    message("Please create a valid object library with method 'ObjectLibrary'.")
    return(invisible(NULL))
  }
  
  index <- .ObjectLibrary.GetIndex(objectLibrary)
  if (is.null(index)) return(invisible(NULL))

  selection <- .ObjectLibrary.QueryFull(objectLibrary, ...)
  
  if (nrow(selection)==0)
  {
    message("No object present in the library for the current selection of parameters.")
    return(invisible(NULL))
  }
  
  # Get ObjectLibrary directory
  elements <- strsplit(objectLibrary, "/")[[1]]
  libDir <- paste(elements[-length(elements)], collapse="/")

  files <- paste(libDir, selection$Path, sep="/")
  print("Removing the following objects:")
  print(selection[, -1])

  # Remove object references from index
  index <- index[!(index$Path %in% selection$Path), ]
  write.csv2(index, file=objectLibrary, row.names=FALSE, na="")

  file.remove(files)
}
