
.onAttach <- function(...)
{
  if (!interactive() || stats::runif(1) > 0.5) return()
  
  tips <- c(
    "Need help? You can find example code for creating various maps at: https://bitbucket.org/NZaAnalysis/thematicmaps.",
    "Submit issues to: https://bitbucket.org/NZaAnalysis/thematicmaps/issues.",
    "Use suppressPackageStartupMessages to eliminate package startup messages."
  )
  
  tip <- sample(tips, 1)
  packageStartupMessage(tip)
}