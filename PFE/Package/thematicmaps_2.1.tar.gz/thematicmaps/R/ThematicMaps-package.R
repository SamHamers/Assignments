
#' @import data.table
NULL


#' Thematic maps.
#'
#' This package contains functions to create thematic maps with multiple layers
#' and aesthetics.
#'
#' @name ThematicMaps-package
#' @docType package
NULL
