
#' AggregateMapData
#'
#' Aggregate polygons in a map
#'
#'
#' @param mapData Map polygon data.
#' @param groupingData Data frame containing the polygon id (first column) and group id.
#' @export
#' @author Mark Klik <mklik@@nza.nl>
AggregateMapData <- function(mapData, groupingData)
{
  if (length(unique(groupingData[, 1])) < nrow(groupingData))
  {
    stop("Each polygon identifier in the grouping data should be defined only once.")
  }
  
  # Use only known IDs
  IDs <- unique(mapData[,1])
  groups <- groupingData[groupingData[,1] %in% IDs, ]
  
  if (nrow(groupingData) != nrow(groups))
  {
    message("Some identifiers in the grouping data are unknown and will be discarded.")
  }

  groups[,2] <- as.character(groups[,2])

  mapPolygons <- MapToGPCPoly(mapData)
  setkeyv(mapPolygons, colnames(mapPolygons)[1])

  grouping <- data.table(groupingData)
  setnames(grouping, colnames(groupingData)[1:2], c(colnames(mapData)[1], "Group"))
  setkeyv(grouping, colnames(grouping)[1])  

  mapGroups <- mapPolygons[grouping,]

  x <- mapGroups[, list(gpc=.PolygonsUnion(Group, gpc)), by=Group]

  y <- GPCPolyToMap(x)
  setnames(y, "Group", colnames(groupingData)[2])

  y
}


.PolygonsUnion <- function(group, gpcPolygons)
{
  sumPolygon <- new("gpc.poly", pts=gpcPolygons[[1]])
  for (polygonID in 2:length(gpcPolygons))
  {
    element <- new("gpc.poly", pts=gpcPolygons[[polygonID]])
    sumPolygon <- .UnionGPCPolygons(sumPolygon, element)
  }

  result <- list()
  data <- get.pts(sumPolygon)
  result[[1]] <- data
  names(result[[1]]) <- paste(group[1], 1:length(data), sep=".")
  names(result) <- group[1]

  result
}


.UnionGPCPolygons <- function(x, y)
{
  spx = as(x,"SpatialPolygons")
  spy = as(y,"SpatialPolygons")
  spres = gUnion(spx,spy)
  
  if (is.null(spres))
  {
    return(new("gpc.poly"))
  }

  as(spres,"gpc.poly")
}

