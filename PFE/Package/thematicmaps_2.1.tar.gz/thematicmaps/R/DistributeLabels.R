
.DistributeLabels <- function

(labelPositions,
### Dataframe of labels with their coordinates. A column 'Label' contains the actual
### text, and columns 'X' and 'Y' contain the coordinates.

sizeXPerCharacter,
### Horizontal (maximum) size of one character in a label.
 
sizeY
### Vertical (maximum) size of a label.
 
)
{

  GetBoundingBox <- function(labelIndex)
  {
    c(labelPositions$correctedX[labelIndex] - labelPositions$halfSizeX[labelIndex],
      labelPositions$correctedX[labelIndex] + labelPositions$halfSizeX[labelIndex],
      labelPositions$correctedY[labelIndex] - 0.5*sizeY)
  }
  
  CheckRange <- function(labelIndex)
  {
    matches <- numeric()
    checkIndex <- labelIndex-1
    while ((checkIndex > 0) && (CheckOverlapY(labelIndex, checkIndex)))
    {
      if (CheckOverlapX(labelIndex, checkIndex))
      {
        matches[length(matches)+1] <- checkIndex
      }
      checkIndex <- checkIndex - 1
    }
    
    matches
  }
  
  CheckOverlapX <- function (labelIndex1, labelIndex2)
  {
    boundingBox1 <- GetBoundingBox(labelIndex1)
    boundingBox2 <- GetBoundingBox(labelIndex2)
    if ((boundingBox1[1] > boundingBox2[2]) || (boundingBox1[2] < boundingBox2[1]))
    {
      return(FALSE)
    }
    
    TRUE
  }
  
  CheckOverlapY <- function(labelIndex1, labelIndex2)
  {
    boundingBox1 <- GetBoundingBox(labelIndex1)
    boundingBox2 <- GetBoundingBox(labelIndex2)
    if (boundingBox1[3] > (boundingBox2[3] + sizeY))
    {
      return(FALSE)
    }

    TRUE
  }

  # Caluclate group numbers based on the corrected coordinates
  CalculateGroups <- function (labelPositions)
  {
    for (labelIndex in 2:nrow(labelPositions))
    {
      group <- labelPositions$Group[labelIndex]
      matches <- CheckRange(labelIndex)
  
      # Found no matches: group number is retained
      if (length(matches) == 0) next
  
      # Calculate all groups found and add current group
      groups <- unique(c(labelPositions$Group[matches], group))
      
      # Found no groups but one or more matches: define new group
      if (!(TRUE %in% (groups > 0)))
      {
        matches[length(matches)+1] <- labelIndex
        groupNr <- max(1, max(labelPositions$Group) + 1)
        labelPositions$Group[matches] <- groupNr
        next
      }
  
      # Found one group (possibly current group)
      if (sum(groups>0) == 1)
      {
        matches[length(matches)+1] <- labelIndex
        groupNr <- max(groups)
        labelPositions$Group[matches] <- groupNr
        next
      }

      # Multiple groups
      matches[length(matches)+1] <- labelIndex
      groupNr <- max(labelPositions$Group) + 1
      labelPositions$Group[matches] <- groupNr
      
      matchedGroups <- groups[groups>0]
      labelPositions$Group[labelPositions$Group %in% matchedGroups] <- groupNr
    }
    
    labelPositions
  }

  AdjustCoordinates <- function(labelPositions)
  {
    groups <- unique(labelPositions$Group[labelPositions$Group > 0])
    for (group in groups)
    {
      groupLabels <- labelPositions[labelPositions$Group == group,]
      minY <- min(groupLabels$Y)
      maxY <- max(groupLabels$Y)
      nrOfLines <- floor((nrow(groupLabels) + 1)/2)
      
      # Enough space between top and bottom points for the lines
      if (nrOfLines == 1)
      {
        lineSize <- maxY - minY
      } else
      {
        lineSize <- (maxY - minY) / (nrOfLines - 1)
      }
      lineSize <- max(lineSize, sizeY)
  
      startCoordinateY <- ((maxY + minY) / 2) - (nrOfLines - 1) * 0.5 * lineSize
  
      # Lines with two labels or more
      if (nrow(groupLabels) > 1)
      {
        for (lineNr in 0:(floor(nrow(groupLabels)/2)-1))
        {
          indexes <- c(1+lineNr*2, 2+lineNr*2)
          groupLabels$correctedY[indexes] <- startCoordinateY + lineNr * lineSize
          if (groupLabels$X[indexes[2]] < groupLabels$X[indexes[1]]) indexes <- rev(indexes)

          groupLabels$correctedX[indexes[1]] <- min(groupLabels$X[indexes[1]], 0.5*(groupLabels$X[indexes[1]] + groupLabels$X[indexes[2]]) - groupLabels$halfSizeX[indexes[1]])
          groupLabels$correctedX[indexes[2]] <- max(groupLabels$X[indexes[2]], 0.5*(groupLabels$X[indexes[1]] + groupLabels$X[indexes[2]]) + groupLabels$halfSizeX[indexes[2]])
        }
      }
      
      # Check for a remaining label
      if ((nrow(groupLabels) %% 2) == 1)
      {
        groupLabels$correctedY[nrow(groupLabels)] <- startCoordinateY + (nrOfLines-1) * lineSize
        groupLabels$correctedX[nrow(groupLabels)] <- groupLabels$X[nrow(groupLabels)]
      }
      
      labelPositions[labelPositions$Group == group,] <- groupLabels
    }
    
    labelPositions
  }
  
  # Calculate boundaries
  labelPositions$halfSizeX <- 0.5 * sizeXPerCharacter * sapply(labelPositions$Label, FUN=nchar)
  labelPositions <- labelPositions[order(labelPositions$Y),]
  labelPositions$correctedX <- labelPositions$X
  labelPositions$correctedY <- labelPositions$Y

  groups <- labelPositions$Group <- -1

  labelPositions <- CalculateGroups(labelPositions)
  
  pass <- 1
  while (FALSE %in% (groups == labelPositions$Group))
  {
    print(paste("Pass:", pass))

    # Calculate corrected coodinates for each label in each group
    labelPositions <- AdjustCoordinates(labelPositions)

    # Calculate all overlapping points and give them group numbers
    groups <- labelPositions$Group
    labelPositions <- CalculateGroups(labelPositions)
    
    pass <- pass + 1
  }
  
  labelPositions$Y <- labelPositions$correctedY
  labelPositions$X <- labelPositions$correctedX

  labelPositions[,1:(ncol(labelPositions)-4)]
}
