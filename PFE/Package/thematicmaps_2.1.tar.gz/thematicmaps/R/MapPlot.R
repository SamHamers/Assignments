#'MapPlot
#'
#'Function to create the basic settings needed to generate maps.
#'
#'@export
#'@author Mark Klik <mklik@@nza.nl>
MapPlot <- function()
{
  theme_nothing <- theme(
    axis.text = element_text(size = rel(0.01), colour="transparent", margin = unit(0, "lines")),
    axis.ticks.x = element_line(colour = "transparent", size = 0.01),
    axis.ticks.y = element_line(colour = "transparent", size = 0.01),
    axis.title.x = element_text(size = rel(0.01), colour="transparent"),
    axis.title.y = element_text(size = rel(0.01), colour="transparent"),
    axis.ticks.length = unit(0, "lines"),
    panel.background = element_blank(),
    panel.border = element_blank(),
    panel.grid.major = element_line(colour = "transparent", size = 0),
    panel.grid.minor = element_line(colour = "transparent", size = 0),
    plot.margin = unit(c(-1.0,-0.2,-1.0,-1.1), "lines"),
    plot.background = element_rect(colour = 'white'), 
    plot.title = element_text(size = rel(1.2)),
    axis.line = element_blank()
  )
  
  p <- ggplot()
  p <- p + coord_equal()
  p + theme_nothing
}
