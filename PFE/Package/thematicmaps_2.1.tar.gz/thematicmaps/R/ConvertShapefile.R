
.ConvertShapefile <- function (shapeFileName, regionName)
{
  gpclibPermit()

  GeometryPolygonData <- readShapeSpatial(shapeFileName)

  GeometryData <- slot(GeometryPolygonData, "data")

  if(!(regionName %in% colnames(GeometryData)))
  {
    stop(paste(c("Error: column", regionName,
      "was not found in the polygon data, please select correct level. Available levels are: ",
      colnames(GeometryData)), collapse=" "))
  }
  
  nrOfRows <- nrow(GeometryData)

  GeometryData <- GeometryData[, c(regionName, setdiff(colnames(GeometryData), regionName))]

  subs <- strsplit(shapeFileName, "/")[[1]]
  dataName <- subs[length(subs)]
  dataName <- paste(substr(dataName, 1, nchar(dataName)-4), sep="")

  result <- list(Data=NULL, Geometry=NULL)

  result$Data <- GeometryData

  if (class(GeometryPolygonData) == "SpatialPointsDataFrame")
  {
    points <- slot(GeometryPolygonData, "coords")
    points <- cbind(regionName=GeometryData[,regionName], points, stringsAsFactors=FALSE)

    result$Geometry <- points
    result$Type <- "Points"

    return(result)
  }

  if (class(GeometryPolygonData) == "SpatialLinesDataFrame")
  {
    PolygonTable <- fortify(GeometryPolygonData, region = regionName)
    
    PolygonTable <- PolygonTable[, c(regionName, setdiff(colnames(PolygonTable), regionName))]

    result$Geometry <- PolygonTable
    result$Type <- "Lines"

    return(result)
  }

  SubGeom <- GeometryPolygonData
  if (class(GeometryPolygonData) == "SpatialPolygonsDataFrame")
  {
    GetPolygonTable <- function(rowCount)
    {
      activeIndex <- rowCount:min(rowCount + 999, nrOfRows)
      slot(SubGeom, "data") <- slot(GeometryPolygonData, "data")[activeIndex,]
      slot(SubGeom, "polygons") <- slot(GeometryPolygonData, "polygons")[activeIndex]
      slot(SubGeom, "plotOrder") <- activeIndex

      SubTable <- fortify(SubGeom, region = regionName)
      colnames(SubTable)[1:2] <- c("x", "y")
      colnames(SubTable)[which(colnames(SubTable) == "id")] = regionName

      SubTable
    }

    rowCount <- 1
    PolygonTable <- GetPolygonTable(rowCount)
    rowCount <- rowCount + 1000
    while (rowCount <= nrOfRows)
    {
      print(rowCount)
      PolygonTable <- rbind(PolygonTable, GetPolygonTable(rowCount))
      rowCount <- rowCount + 1000
    }

    PolygonTable <- PolygonTable[, c(regionName, setdiff(colnames(PolygonTable), regionName))]    
    result$Type <- "Polygons"
    result$Geometry <- PolygonTable

    return(result)
  }

  return(NULL)
}
