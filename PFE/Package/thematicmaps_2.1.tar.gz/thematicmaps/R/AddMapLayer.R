#'AddMapLayer
#'
#'Map of the Netherlands.
#'
#'
#'@param mapPlot Existing ggplot, for example generated with MapPlot()
#'@param mapData Dataframe containing the map data. Each row in the dataframe
#'should contain a polygon point, Columns required are: 'x', 'y', 'hole',
#''order' and 'group'. Furthermore, a column is required containing the
#'identifier for the polygon region (for example 'zipcode'). This column MUST
#'be the first column of the dataframe or mapDataIdentifierColumn (see below)
#'must be specified.
#'@param locationData Dataframe of data to be displayed in the map. The second
#'column contains the data to be displayed and the first column the location.
#'This location must correspond to a valid region identifier as contained in
#'the mapData dataframe. If NULL, the polygons will only be drawn if
#'backgroungAreasColor is set to a color.
#'@param categoryColors You can tune the legend and its colors to your specific
#'needs. The AddMapLayer function uses the ggplot method 'scale_fill_manual' to
#'set the legend for factor data and the ggplot method 'scale_fill_gradientn'
#'for continuous data. You can set parameters for these methods by setting the
#'categoryColors argument to a list of named parameters.
#'@param legendPosition The position of the legend of the graphic. Valid values
#'are "top", "right", "bottom", "left", "none", and a vector c(x,y), specifying
#'the exact position (coordinates between 0 and 1).
#'@param mapDataIdentifierColumn If NULL, the name of the first column of
#'mapData will be used as the unique identifier for the polygons. Otherwise,
#'the column with name equal to this parameter will be used.
#'@param lineColor Color of the line surrounding the displayed areas.
#'@param zoomBoundary Represented in the format c(x1, x2, y1, y2). x1 and x2
#'correspond to the left and right coordinates of the boundingbox around the
#'map. y1 and y2 correspond to the vertical bounding box coordinates. For
#'example zoomMatrix <- c(0,0.5,0.5,1) would zoom the image to the top-left
#'quadrant. If NULL, the default ggplot zoom is applied and all zooming occurs
#'relative to this default zoom.
#'@param backgroundAreasColor Fill color of the missing areas. If NULL, the
#'missing areas will not be drawn.
#'@param \dots Extra arguments that will be passed to ggplot2's' geom_polygon
#'function,
#'@export
#'@return Return ggplot2 layer
#'@author Mark Klik <mklik@@nza.nl>
AddMapLayer <- function(mapPlot, mapData, locationData = NULL, categoryColors = NULL, legendPosition = NULL,
    mapDataIdentifierColumn = NULL, lineColor = "white", zoomBoundary = NULL, backgroundAreasColor = "lightgrey", ...)
{

  if (is.null(mapDataIdentifierColumn))
  {
    mapDataIdentifierColumn <- colnames(mapData)[1]
  }

  if (is.null(locationData))
  {
    locationData <- data.frame(character(0), character(0))
    colnames(locationData) <- c(mapDataIdentifierColumn, "Value")
  }

  mapData <- as.data.frame(mapData)
  locationData <- as.data.frame(locationData)
  
  unknownIdentifiers <- locationData[!(locationData[,1] %in% mapData[,mapDataIdentifierColumn]), 1]
  for (identifier in unknownIdentifiers)
  {
    print(paste("Location identifier '", identifier, "' is unknown, dropping line", sep=""))
  }

  polygonsWithData <- merge(mapData, locationData, by.x=mapDataIdentifierColumn, by.y=colnames(locationData)[1], all.x=FALSE)
  holePolygons <- polygonsWithData[polygonsWithData$hole == TRUE,]
  holePolygons <- holePolygons[order(holePolygons$order),]
  polygonsWithData <- polygonsWithData[polygonsWithData$hole == FALSE,]
  polygonsWithData <- polygonsWithData[order(polygonsWithData$order),]
  dataColumName <- colnames(locationData)[2]

  if (!is.null(zoomBoundary))
  {
    horizontalRange <- range(polygonsWithData$x)
    verticalRange <- range(polygonsWithData$y)
    width <- horizontalRange[2] - horizontalRange[1]
    height <- verticalRange[2] - verticalRange[1]
    horizontalRange <- c(horizontalRange[1] + zoomBoundary[1]*width, horizontalRange[1] + zoomBoundary[2]*width)
    verticalRange <- c(verticalRange[1] + zoomBoundary[1]*height, verticalRange[1] + zoomBoundary[2]*height)
  }

  p <- mapPlot
  
  if (!is.null(backgroundAreasColor))
  {
    missingPolygonsWithData <- mapData[!(mapData[, mapDataIdentifierColumn] %in% locationData[, 1]), ]
    missingHolePolygons <- missingPolygonsWithData[missingPolygonsWithData$hole == TRUE,]
    missingHolePolygons <- missingHolePolygons[order(missingHolePolygons$order),]
    missingPolygonsWithData <- missingPolygonsWithData[missingPolygonsWithData$hole == FALSE,]
    missingPolygonsWithData <- missingPolygonsWithData[order(missingPolygonsWithData$order),]
    if (nrow(missingPolygonsWithData) > 0)
    {
      p <- p + geom_polygon(data=missingPolygonsWithData, color=lineColor, fill=backgroundAreasColor, aes_string(x="x", y="y", group="group"), ...)
    }
    if (nrow(missingHolePolygons) > 0)
    {
      p <- p + geom_polygon(data=missingHolePolygons, aes_string(x="x", y="y", group="group"), fill=backgroundAreasColor, ...)
    }
  }
  
  if (nrow(polygonsWithData) > 0)
  {
    p <- p + geom_polygon(data=polygonsWithData, color=lineColor, aes_string(x="x", y="y", group="group", fill=dataColumName), ...)
    if (nrow(holePolygons) > 0)
    {
      p <- p + geom_polygon(data=holePolygons, aes_string(x="x", y="y", group="group"), fill="white", ...)
    }
  }

  if (!is.null(categoryColors))
  {
    if (is.factor(polygonsWithData[, dataColumName]))
    {
      p <- p + do.call(scale_fill_manual, categoryColors)
    } else
    {
      if ("values" %in% names(categoryColors))
      {
        # The rescaler has to be turned of in case values are supplied
        categoryColors$rescaler = function(x, ...) x
        categoryColors$oob = identity
      }
      p <- p + do.call(scale_fill_gradientn, categoryColors)
    }
  }

  if (!is.null(zoomBoundary))
  {
    p <- p + scale_x_continuous(limits = horizontalRange)
    p <- p + scale_y_continuous(limits = verticalRange)
  }

  if (!is.null(legendPosition))
  {
    p <- p + opts(legend.position = legendPosition)
  }

  p
}

