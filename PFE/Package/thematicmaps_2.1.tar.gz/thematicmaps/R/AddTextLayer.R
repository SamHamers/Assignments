#'AddTextLayer
#'
#'Add points to the map.
#'
#'
#'@param mapPlot Existing ggplot, for example generated with MapPlot()
#'@param coordinateData Dataframe containing coordinate data. Columns required
#'are: 'X' and 'Y'. Furthermore, a column is required containing the identifier
#'for the polygon region (for example 'zipcode'). This column MUST be the first
#'column of the dataframe.
#'@param locationData Dataframe of data to be displayed in the map. A column
#'with the name 'columnNameSize' can be specified that contains the size of the
#'text. A column with the name 'columnNameColor' can be specified for the
#'color. A column 'Label' contains the actual text. The first column must
#'contain the locationdata and the values in this column must correspond to a
#'valid region identifier as contained in the coordinateData dataframe.
#'@param columnNameSize If NULL, the name of the first column of mapData will
#'be used as the unique identifier for the polygons. Otherwise, the column with
#'name equal to this parameter will be used.
#'@param columnNameColor If NULL, the name of the first column of mapData will
#'be used as the unique identifier for the polygons. Otherwise, the column with
#'name equal to this parameter will be used.
#'@param legendSize Legend with parameters defining the size legend.
#'@param legendColor Legend with parameters defining the size legend.
#'@param labelSize The horizontal and vertical size of one character in a
#'label. This information is used to garantee that no labels will overlap in
#'the image. The format is c(sizeX, sizeY), where sizeX is the horizontal- and
#'sizeY the vertical size. If NULL, no automatic position adjustments will be
#'applied.
#'@param \dots Extra arguments that will be passed to ggplot2's' geom_point
#'function,
#'@export
#'@return Return ggplot2 layer
#'@author Mark Klik <mklik@@nza.nl>
AddTextLayer <- function(mapPlot, coordinateData, locationData = NULL, columnNameSize = NULL,
    columnNameColor = NULL, legendSize = NULL, legendColor = NULL, labelSize = NULL, ...)
{
  unknownIdentifiers <- locationData[!(locationData[,1] %in% coordinateData[,1]), 1]
  for (identifier in unknownIdentifiers)
  {
    print(paste("Location identifier '", identifier, "' is unknown, dropping line", sep=""))
  }

  if ("Label" %in% colnames(coordinateData)) coordinateData <- coordinateData[, colnames(coordinateData)[colnames(coordinateData)!="Label"]]
  pointLocations <- merge(coordinateData, locationData, by.x=colnames(coordinateData)[1], by.y=colnames(locationData)[1])

  if (!is.null(labelSize))
  {
    pointLocations <- .DistributeLabels(pointLocations, labelSize[1], labelSize[2])
  }
  
  p <- mapPlot

  if (!is.null(columnNameSize) && !is.null(columnNameColor))
  {
    p <- p + geom_text(data=pointLocations, aes_string(x="X", y="Y", size=columnNameSize, color=columnNameColor, label="Label"), ...)
  } else
  if (!is.null(columnNameColor))
  {
    legendSize <- NULL
    p <- p + geom_text(data=pointLocations, aes_string(x="X", y="Y", color=columnNameColor, label="Label"), ...)
  } else
  if (!is.null(columnNameSize))
  {
    legendColor <-NULL
    p <- p + geom_text(data=pointLocations, aes_string(x="X", y="Y", size=columnNameSize, label="Label"), ...)
  } else
  {
    legendSize <- NULL
    legendColor <-NULL
    p <- p + geom_text(data=pointLocations, aes_string(x="X", y="Y", label="Label"), ...)
  }

#   if (!is.null(legendSize))
#   {
#     p <- p + do.call(scale_size, legendSize)
#   }
# 
#   if (!is.null(legendColor))
#   {
#     if (is.factor(pointLocations[,columnNameColor]))
#     {
#       p <- p + do.call(scale_color_manual, legendColor)
#     } else
#     {
#       p <- p + do.call(scale_color_gradientn, legendColor)
#     }
#   }

  p
}

