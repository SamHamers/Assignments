

#' SampleMapLibrary
#'
#' Retrieve the library with sample maps from the package data
#'
#'
#' @export
#' @return A reference to the sample map library from the package.
#' @author Mark Klik <mklik@@nza.nl>
#'
SampleMapLibrary <- function()
{
  mapLib <- paste(path.package("ThematicMaps"), "SampleData", sep = "/")

  MapDataLibrary(mapLib)
}
