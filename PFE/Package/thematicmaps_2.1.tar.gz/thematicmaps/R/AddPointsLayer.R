#'AddPointsLayer
#'
#'Add points to the map.
#'
#'
#'@param mapPlot Existing ggplot, for example generated with MapPlot()
#'@param coordinateData Dataframe containing coordinate data. Columns required
#'are: 'X' and 'Y'. Furthermore, a column is required containing the identifier
#'for the polygon region (for example 'zipcode'). This column MUST be the first
#'column of the dataframe.
#'@param locationData Dataframe of data to be displayed in the map. If NULL, all
#'datapoints from the coordinate data are displayed in the backgroundPointsColor.
#'A columns with the name 'columnNameSize' can be specified that contains the data that
#'has to be displayed as points with various size. A column with the name
#''columnNameColor' can be specified for points with color scale. The first
#'column must contain the locationdata and the values in this column must
#'correspond to a valid region identifier as contained in the coordinateData
#'dataframe.
#'@param columnNameSize If NULL, the name of the first column of locationData will
#'be used as the unique identifier for the polygons. Otherwise, the column with
#'name equal to this parameter will be used.
#'@param columnNameColor If NULL, the name of the first column of locationData will
#'be used as the unique identifier for the polygons. Otherwise, the column with
#'name equal to this parameter will be used.
#'@param legendSize Legend with parameters defining the size legend.
#'@param legendColor Legend with parameters defining the color legend.
#'@param \dots Extra arguments that will be passed to ggplot2's' geom_point
#'function,
#'@export
#'@return Return ggplot2 layer
#'@author Mark Klik <mklik@@nza.nl>
AddPointsLayer <- function(mapPlot, coordinateData, locationData = NULL, columnNameSize = NULL,
    columnNameColor = NULL, legendSize = NULL, legendColor = NULL, ...)
{
  if (is.null(locationData))
  {
    pointLocations = coordinateData
  } else
  {
    unknownIdentifiers <- locationData[!(locationData[,1] %in% coordinateData[,1]), 1]
    for (identifier in unknownIdentifiers)
    {
      print(paste("Location identifier '", identifier, "' is unknown, dropping line", sep=""))
    }
    
    pointLocations <- merge(coordinateData, locationData, by.x=colnames(coordinateData)[1], by.y=colnames(locationData)[1])
  }

  p <- mapPlot

  if (!is.null(columnNameSize) && !is.null(columnNameColor))
  {
    p <- p + geom_point(data=pointLocations, aes_string(x="X", y="Y", size=columnNameSize, color=columnNameColor), ...)
  } else
  if (!is.null(columnNameColor))
  {
    legendSize <- NULL
    p <- p + geom_point(data=pointLocations, aes_string(x="X", y="Y", color=columnNameColor), ...)
  } else
  if (!is.null(columnNameSize))
  {
    legendColor <-NULL
    p <- p + geom_point(data=pointLocations, aes_string(x="X", y="Y", size=columnNameSize), ...)
  } else
  {
    legendSize <- NULL
    legendColor <-NULL
    p <- p + geom_point(data=pointLocations, aes_string(x="X", y="Y"), ...)
  }

  if (!is.null(legendSize))
  {
    if (is.factor(pointLocations[,columnNameSize]))
    {
      p <- p + do.call(scale_size_manual, legendSize)
    } else
    {
      p <- p + do.call(scale_size, legendSize)
    }
  }

  if (!is.null(legendColor))
  {
    if (is.factor(pointLocations[,columnNameColor]))
    {
      p <- p + do.call(scale_color_manual, legendColor)
    } else
    {
      p <- p + do.call(scale_color_gradientn, legendColor)
    }
  }

  p
}

