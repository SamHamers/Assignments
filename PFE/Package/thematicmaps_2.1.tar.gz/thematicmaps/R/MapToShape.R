
#' MapinfoToShapefile
#'
#' Convert all MapInfo files in a directory to shapefiles and copy to an output directory
#'
#'
#' @param mapinfoDirectory Base directory of the MapInfo data
#' @param outputDirectory Base directory for the generated shapefiles
#' @param retainDirectoryStructure If TRUE, subdirectory structure of mapinfoDirectory will be copied
#' @export
#' @author Mark Klik <mklik@@nza.nl>
MapinfoToShapefile <- function(mapinfoDirectory, outputDirectory, retainDirectoryStructure=TRUE)
{
  if (substr(mapinfoDirectory, nchar(mapinfoDirectory), nchar(mapinfoDirectory)) == "/")
  {
    mapinfoDirectory <- substr(mapinfoDirectory, 1, nchar(mapinfoDirectory)-1)
  }

  if (substr(outputDirectory, nchar(outputDirectory), nchar(outputDirectory)) == "/")
  {
    outputDirectory <- substr(outputDirectory, 1, nchar(outputDirectory)-1)
  }

  files <- list.files(mapinfoDirectory, pattern=".tab$", recursive=TRUE, full.names=TRUE)
  files <- c(files, list.files(mapinfoDirectory, pattern=".TAB$", recursive=TRUE, full.names=TRUE))
  
  WriteShape <- function()
  {
    if(class(mapInfoFile)=="SpatialPolygonsDataFrame")
    {
      writePolyShape(mapInfoFile, paste(outputDirectory, "/", deltaDir, "/", layer,".shp",sep=""))
    }
    
    if(class(mapInfoFile)=="SpatialLinesDataFrame")
    {
      writeLinesShape(mapInfoFile, paste(outputDirectory, "/", deltaDir, "/", layer,".shp",sep=""))
    }
    
    if(class(mapInfoFile)=="SpatialPointsDataFrame")
    {
      writePointsShape(mapInfoFile, paste(outputDirectory, "/", deltaDir, "/", layer,".shp",sep=""))
    }
  }
  
  if (!retainDirectoryStructure)
  {
    for (file in files)
    {
      fileName <- strsplit(file, "/")[[1]]
      dir <- paste(fileName[-length(fileName)], collapse="/")
      fileName <- fileName[length(fileName)]

      layer <- substr(fileName, 1, nchar(fileName)-4)
      mapInfoFile = readOGR(dir, layer)
      deltaDir <- ""
      
      WriteShape()
    }
  } else
  {
    for (file in files)
    {
      fileName <- strsplit(file, "/")[[1]]
      dir <- paste(fileName[-length(fileName)], collapse="/")
      fileName <- fileName[length(fileName)]
      
      layer <- substr(fileName, 1, nchar(fileName)-4)
      mapInfoFile = readOGR(dir, layer)
      
      deltaDir <- substr(dir, nchar(mapinfoDirectory)+2, nchar(dir))
      
      # Generate output directories:
      dirSteps <- strsplit(deltaDir, "/")
      deltaStep <- outputDirectory
      for (dirStep in dirSteps[[1]])
      {
        deltaStep <- paste(deltaStep, dirStep, sep="/")
        if (!file.exists(deltaStep))
        {
          dir.create(deltaStep)
        }
      }
      
      WriteShape()
    }
  }
}
