
#' MapDataLibrary
#'
#' Create a new object library with map-related data
#'
#'
#' @param mapLibraryDirectory Path to the directory where the library exists or a new library
#' should be created.
#' @param additionalMetaFields A vector with the names of additional metadata fields
#' @export
#' @return A reference to a newly created or existing object library.
#' @author Mark Klik <mklik@@nza.nl>
MapDataLibrary <- function(mapLibraryDirectory, additionalMetaFields=NULL)
{
  lib <- paste(mapLibraryDirectory, "ObjectLibrary", sep="/")
  
  minimalColumns <- c("Year", "Area", "Level", "Type", "Source")
  
  if (file.exists(lib))
  {
    mapLib <- ObjectLibrary(mapLibraryDirectory)

    # Check for mandatory columns
    if (sum(minimalColumns %in% colnames(ObjectLibrary.Query(mapLib)))!=length(minimalColumns))
    {
      stop("Library is an object library but does not have the required fields needed for a MapDataLibrary. Please create a new library with method MapDataLibrary().")
    }
    
    return(mapLib)
  }

  ObjectLibrary(mapLibraryDirectory, unique(c(minimalColumns, additionalMetaFields)))
}
