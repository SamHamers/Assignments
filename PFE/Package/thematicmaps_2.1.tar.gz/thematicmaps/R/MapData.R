
.CreateGPCPolyGroup <- function(group, gpcPoly)
{
  result <- list()

  result[[1]] <- gpcPoly
  names(result[[1]]) <- group

  result
}

.CreateGPCPoly <- function(ID, x, y, hole)
{
  result <- list()

  result[[1]] <- list()
  result[[1]]$x <- x
  result[[1]]$y <- y
  result[[1]]$hole <- hole[1]

  result
}

.ExpandGpcPolyGroup <- function(gpcPoly)
{
  data.table(group=names(gpcPoly[[1]]), gpcGroup=gpcPoly[[1]], piece=1:length(gpcPoly[[1]]))
}

.ExpandGpcPoly <- function(gpcPoly)
{
  data.table(x=gpcPoly[[1]]$x, y=gpcPoly[[1]]$y, hole=gpcPoly[[1]]$hole)
}


#'MapToGPCPoly
#'
#'Convert map data to a list of GPC polygons (for use with the rgeos package).
#'
#'
#'@param mapData Map polygon data.
#'@export
#'@author Mark Klik <mklik@@nza.nl>
MapData.ToGPCPoly <- function(mapData)
{
  map <- data.table(mapData)

  setnames(map, colnames(mapData)[1], "ID")

  x <- map[, list(ID=ID[1], gpc= .CreateGPCPoly(ID, x, y, hole)), by=group]

  y <- x[, list(gpc=.CreateGPCPolyGroup(group, gpc)), by=ID]

  setnames(y, "ID", colnames(mapData)[1])

  y
}


#' MapData.FromGPCPoly
#'
#' Convert a data.table of GPC polygons (rgeos package) to map data.
#'
#'
#' @param gpcPolygons A named list of GPC polygons as defined in the rgeos package.
#' @export
#' @author Mark Klik <mklik@@nza.nl>
MapData.FromGPCPoly <- function(gpcPolygons)
{
  colName <- colnames(gpcPolygons)[1]

  setnames(gpcPolygons, colName, "ID")

  groupTable <- gpcPolygons[, .ExpandGpcPolyGroup(gpc), by=ID]

  table <- groupTable[, .ExpandGpcPoly(gpcGroup), by="ID,group,piece"]

  table$order <- 1:nrow(table)

  setnames(table, "ID", colName)

  as.data.frame(table)[,c(colName, "x", "y", "order", "hole", "piece", "group")]
}


#' MapData.ShapeInfo
#'
#' Display some info on a shapefile
#'
#'
#' @param shapeFileName Shapefile to show info on
#' @export
#' @return Some basic info on a shapefile.
#' @author Mark Klik <mklik@@nza.nl>
MapData.ShapeInfo <- function(shapeFileName)
{
  GeometryPolygonData <- readShapeSpatial(shapeFileName)

  print(paste("Shapefile is of class", class(GeometryPolygonData)))

  print(slotNames(GeometryPolygonData))

  GeometryData <- slot(GeometryPolygonData, "data")

  print("The following columns are available in the shapefile dataset:")
  print(colnames(GeometryData))

  print("")
  print("Data header")
  print(head(GeometryData))
}


#' MapData.FromShapefile
#'
#' Convert a shapfile into data that can be used to plot maps with package ThematicMaps
#'
#'
#' @param shapeFileName Shapefile that you wish to convert
#' @param regionName Name of the column that contains the region identifier.
#' @param simplifyTolerance You can specify a tolerance here which is used internally to call 'gSimplify'. This can help
#' to clean up badly formed polygons. Use a tolerance as small as possible.
#' @export
#' @return List with data, geometry and type of the shapefile.
#' @author Mark Klik <mklik@@nza.nl>
MapData.FromShapefile <- function(shapeFileName, regionName, simplifyTolerance = NULL)
{
  gpclibPermit()

  GeometryPolygonData <- readShapeSpatial(shapeFileName)

  GeometryData <- slot(GeometryPolygonData, "data")

  if(!(regionName %in% colnames(GeometryData)))
  {
    stop(paste(c("Error: column", regionName,
      "was not found in the polygon data, please select correct level. Available levels are: ",
      colnames(GeometryData)), collapse=" "))
  }

  nrOfRows <- nrow(GeometryData)

  GeometryData <- GeometryData[, c(regionName, setdiff(colnames(GeometryData), regionName))]

  subs <- strsplit(shapeFileName, "/")[[1]]
  dataName <- subs[length(subs)]
  dataName <- paste(substr(dataName, 1, nchar(dataName)-4), sep="")

  result <- list(Data=NULL, Geometry=NULL)

  result$Data <- GeometryData

  if (class(GeometryPolygonData) == "SpatialPointsDataFrame")
  {
    points <- slot(GeometryPolygonData, "coords")
    points <- cbind(regionName=GeometryData[,regionName], points, stringsAsFactors=FALSE)

    result$Geometry <- points
    result$Type <- "Points"

    return(result)
  }

  if (class(GeometryPolygonData) == "SpatialLinesDataFrame")
  {
    # Always takes basic ID as grouping parameter
    PolygonTable <- fortify(GeometryPolygonData)

    if (length(unique(PolygonTable$id)) != length(unique(GeometryData[, regionName])))
    {
      stop("Specified regionName is not the lowest level of the line data!")
    }

    PolygonTable <- PolygonTable[, c("id", setdiff(colnames(PolygonTable), "id"))]
    colnames(PolygonTable) <- c(regionName, colnames(PolygonTable)[-1])

    result$Geometry <- PolygonTable
    result$Type <- "Lines"

    return(result)
  }

  SubGeom <- GeometryPolygonData
  if (class(GeometryPolygonData) == "SpatialPolygonsDataFrame")
  {
    GetPolygonTable <- function(rowCount)
    {
      activeIndex <- rowCount:min(rowCount + 999, nrOfRows)
      slot(SubGeom, "data") <- slot(GeometryPolygonData, "data")[activeIndex,]
      slot(SubGeom, "polygons") <- slot(GeometryPolygonData, "polygons")[activeIndex]
      slot(SubGeom, "plotOrder") <- activeIndex

      if (!is.null(simplifyTolerance))
      {
        SubGeom <- gSimplify(SubGeom, tol = simplifyTolerance)
      }
      SubGeom <- gBuffer(SubGeom, byid=TRUE, width=0)

      SubTable <- fortify(SubGeom, region = regionName)
      colnames(SubTable)[1:2] <- c("x", "y")
      colnames(SubTable)[which(colnames(SubTable) == "id")] = regionName

      SubTable
    }

    rowCount <- 1
    PolygonTable <- GetPolygonTable(rowCount)
    rowCount <- rowCount + 1000
    while (rowCount <= nrOfRows)
    {
      print(rowCount)
      PolygonTable <- rbind(PolygonTable, GetPolygonTable(rowCount))
      rowCount <- rowCount + 1000
    }

    PolygonTable <- PolygonTable[, c(regionName, setdiff(colnames(PolygonTable), regionName))]
    result$Type <- "Polygons"
    result$Geometry <- PolygonTable

    return(result)
  }

  return(NULL)
}


#' MapData.Aggregate
#'
#' Aggregate polygons in a map
#'
#'
#' @param mapData Map polygon data.
#' @param groupingData Data frame containing the polygon id (first column) and group id.
#' @export
#' @author Mark Klik <mklik@@nza.nl>
MapData.Aggregate <- function(mapData, groupingData)
{
  if (length(unique(groupingData[, 1])) < nrow(groupingData))
  {
    stop("Each polygon identifier in the grouping data should be defined only once.")
  }

  # get all IDs
  IDs <- unique(mapData[,1])

  missingIDs <- IDs[!(IDs %in% groupingData[,1])]
  if (length(missingIDs)>0)
  {
    print(paste("The following IDs are missing in the grouping data:", paste(missingIDs, collapse=", ")))
    stop("Missing identifiers found.")
  }

  groups <- groupingData[groupingData[,1] %in% IDs, ]
  if (nrow(groupingData) != nrow(groups))
  {
    message("Some identifiers in the grouping data are unknown and will be discarded.")
  }

  groups[,2] <- as.character(groups[,2])

  mapPolygons <- MapData.ToGPCPoly(mapData)
  setkeyv(mapPolygons, colnames(mapPolygons)[1])

  grouping <- data.table(groups)
  setnames(grouping, colnames(grouping)[1:2], c(colnames(mapData)[1], "Group"))
  setkeyv(grouping, colnames(grouping)[1])

  mapGroups <- mapPolygons[grouping, ]

  x <- mapGroups[, list(gpc=.PolygonsUnion(Group, gpc)), by=Group]

  y <- MapData.FromGPCPoly(x)
  setnames(y, "Group", colnames(groups)[2])

  y
}


# The result is now returned as a SpatialPolygon to avoid problems with holes
.PolygonsUnion <- function(group, gpcPolygons)
{
  sumPolygon <- new("gpc.poly", pts=gpcPolygons[[1]])
  sumPolygon <- as(sumPolygon, "SpatialPolygons")
  if (length(gpcPolygons)>1)
  {
    for (polygonID in 2:length(gpcPolygons))
    {
      element <- new("gpc.poly", pts=gpcPolygons[[polygonID]])
      element <- as(element, "SpatialPolygons")

      sumPolygon <- gUnion(sumPolygon, element)
      sumPolygon <- createSPComment(sumPolygon)
    }
  }

  sumPolygon <- as(sumPolygon,"gpc.poly")

  result <- list()
  data <- get.pts(sumPolygon)
  result[[1]] <- data
  names(result[[1]]) <- paste(group[1], 1:length(data), sep=".")
  names(result) <- group[1]

  result
}


