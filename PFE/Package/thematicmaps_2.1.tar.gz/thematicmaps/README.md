# Package thematicmaps

Install this package with

```r
devtools::install_git("https://gitlab.nza.nl/PackagesNZa/ThematicMaps")
```